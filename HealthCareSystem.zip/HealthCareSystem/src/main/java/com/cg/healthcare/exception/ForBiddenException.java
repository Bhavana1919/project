package com.cg.healthcare.exception;
/**
 * @category Exception
 */
public class ForBiddenException extends Exception{
	
	
	private static final long serialVersionUID = -8320602447892236495L;

	public ForBiddenException(String m) {
		super(m);
	}

}
