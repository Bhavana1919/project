import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TestResultService } from 'src/app/test-result.service';

import { TestResult } from '../TestResult';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  testResultid: number;
  test:TestResult;

  constructor(private actRouter:ActivatedRoute,private eService:TestResultService,private router:Router) { }


  ngOnInit(): void {
    this.test=new TestResult();
    this.testResultid=this.actRouter.snapshot.params['testResultid'];
    this.eService.getTestResultById(this.testResultid).subscribe(data =>{
      this.test=data;
    });
  }
  updateData(){
    this.test.testResultid = this.testResultid;
    this.eService.updateTestResult(this.test).subscribe(res =>{
      this.router.navigate(['/testresult/all'])
    });
  }
}

