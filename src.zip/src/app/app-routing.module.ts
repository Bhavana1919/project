import {  NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AllTestresultComponent } from './test-result/all-testresult/all-testresult.component';
import { CreateComponent } from './test-result/create/create.component';
import { TestResultComponent } from './test-result/test-result.component';
import { UpdateComponent } from './test-result/update/update.component';



const routes: Routes = [
 
  {

    path:'testresult', component: TestResultComponent ,
    children: [
      { path: 'add', component: CreateComponent },
      { path: 'all', component: AllTestresultComponent },
      { path: 'updateresult/:testResultid', component: UpdateComponent }]
  },
 

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

