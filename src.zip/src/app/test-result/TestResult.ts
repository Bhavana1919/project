export class TestResult {
    testResultid: number;
    testReading: number;
    testcondition: string;
  }
  